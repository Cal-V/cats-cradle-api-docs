import React from 'react'

function RouteDoc({routeData}) {
    if (routeData?.name){
        return (
            <div>
                <h2>{routeData.name}</h2>
                <p><b>{routeData.route}</b></p>
                <p><b>{routeData.method}</b></p>
                {routeData?.input ? <><p>Input:</p><code>{JSON.stringify(routeData.input)}</code></> : <></>}
                <p>Output:</p><code>{JSON.stringify(routeData.output)}</code>
            </div>
        )}
    else{
        return(<div></div>)}
}

export default RouteDoc